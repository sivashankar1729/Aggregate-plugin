alter table aq_documents modify documentId varchar2(255 char);
alter table aq_document_property modify documentId varchar2(255 char) not null;
alter table aq_document_property_value modify documentPropertyId number(19,0) not null;
alter table aq_agg_documents modify documentId varchar2(255 char);

insert into aggregate_Releases (id, version, releasedate, description) VALUES(aggregate_releases_s.nextval, '9.7.2 seq-01', SYSDATE, 'Increases size of documentId columns to work with CMIS plugin.');