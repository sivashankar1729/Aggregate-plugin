alter table aq_agg_aggregates drop constraint pk_aq_agg_aggregates;
alter table aq_agg_aggregates add latest number(1,0) default 1 not null;
alter table aq_agg_aggregates add constraint pk_aq_agg_aggregates primary key (parentId, childId, latest);

insert into aggregate_Releases (id, version, releasedate, description) VALUES(aggregate_releases_s.nextval, '9.7.2 seq-03', SYSDATE, 'Adds column [latest] to aq_agg_aggregates table.');