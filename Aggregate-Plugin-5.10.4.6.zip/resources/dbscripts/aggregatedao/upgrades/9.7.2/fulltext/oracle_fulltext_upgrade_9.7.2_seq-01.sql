-- if executed from Oracle SQL Developer, set Tools->Preferences->Database->PL/SQL Compiler -> PLScope Identifiers = None
-- or execute "ALTER SESSION SET PLSCOPE_SETTINGS = 'IDENTIFIERS:NONE';"

create table aq_aggregate_roles (
  aggregateId number(19,0),
  roleName varchar2(100 char),
  
  constraint pk_aq_aggregate_roles primary key (aggregateId, roleName),
  constraint fk_aq_aggregate_roles_a foreign key (aggregateId) references aq_aggregate (objectId) on delete cascade
);

create table aq_composite_roles (
  compositeId number(19,0),
  roleName varchar2(50 char),
  compositeSize number(19,0),
  
  constraint uk_aq_composite_roles unique (compositeId, roleName)
);
create sequence aq_composite_roles_s;

insert into aq_composite_roles (compositeId, roleName, compositeSize) values (aq_composite_roles_s.nextval, null, 0);

alter table aq_fulltext drop constraint fk_aq_fulltext_ad;
update aq_fulltext set aggregateId = null where documentId is not null;
-- TODO there can be duplicate documentIds
alter table aq_fulltext add constraint fk_aq_fulltext_ad foreign key (documentId) references aq_documents (documentId) on delete cascade;

drop index idx_aq_aggregate_links_r;
drop index idx_aq_aggregate_links_a;
drop index idx_aq_aggregate_links_d;
alter table aq_aggregate_links drop constraint uk_aq_aggregate_links;
alter table aq_aggregate_links modify documentId varchar2(255 char);
alter table aq_aggregate_links add compositeRoleId number(19,0);
alter table aq_aggregate_links add fulltextId number(19,0);

merge into aq_aggregate_links links using (
  select compositeId, compositeSize from aq_composite_roles
) cr on (cr.compositeSize = 0)
when matched then update
  set links.compositeRoleId = cr.compositeId;
  
merge into aq_aggregate_links links using (
  select objectId, aggregateId from aq_fulltext where aggregateId is not null
) ft on (ft.aggregateId = links.aggregateId)
when matched then update
	set links.fulltextId = ft.objectId;
	
merge into aq_aggregate_links links using (
  select objectId, documentId from aq_fulltext where documentId is not null
) ft on (ft.documentId = links.documentId)
when matched then update
	set links.fulltextId = ft.objectId;

alter table aq_aggregate_links add constraint uk_aq_aggregate_links unique (rootId, aggregateId, documentId, compositeRoleId, fulltextId);
alter table aq_aggregate_links add constraint fk_aq_aggregate_links_d foreign key (documentId) references aq_documents (documentId) on delete cascade;
alter table aq_aggregate_links add constraint fk_aq_aggregate_links_f foreign key (fulltextId) references aq_fulltext (objectId) on delete cascade;
create index idx_aq_aggregate_links_rcf on aq_aggregate_links(rootId, compositeRoleId, fulltextId);

create trigger aq_composite_roles_delete before delete on aq_composite_roles for each row
begin -- begin
  delete from aq_aggregate_links where compositeRoleId = :old.compositeId;
end; -- end
/

drop trigger aq_agg_documents_insert;
drop trigger aq_agg_documents_update;

create or replace trigger aq_documents_insert after insert on aq_documents for each row
begin -- begin
  insert into aq_fulltext (objectId, documentId, text) values (aq_fulltext_s.NEXTVAL, :new.documentId, 'x');
end; -- end
/

create or replace trigger aq_documents_update after update on aq_documents for each row
begin -- begin
  update aq_fulltext set text = 'x' where documentId = :new.documentId;
end; -- end
/

create or replace procedure aq_fulltext_ds (
  rid in rowid,
  tlob in out clob) is
  
  -- begin
  v_blob blob;
  v_clob clob;
  v_aggregateId number(19,0);
  v_documentId varchar2(50 char);
  -- end
begin -- begin
  select aggregateId, documentId into v_aggregateId, v_documentId from aq_fulltext where rowid = rid;
  
  if v_aggregateId is not null then
    select '<aggregate>' || text || '</aggregate>' into tlob from aq_aggregate_flat where aggregateId = v_aggregateId for update;
  elsif v_documentId is not null then
  	select content into v_blob from aq_documents where documentId = v_documentId for update;
  	
  	dbms_lob.createtemporary(v_clob, true);
  	ctx_doc.ifilter(v_blob, v_clob);
  	tlob := '<document>' || v_clob || '</document>';
  	dbms_lob.freetemporary(v_clob);
  end if;
  
end; -- end
/

create or replace procedure denormalize_aggregate_links(aId number, ancestors number default 1) as
  -- begin
  pathExists number(19,0);
  nextCompositeId number(19,0);
  nextCompositeSize number(19,0);
  -- end
begin -- begin
  delete from aq_aggregate_links where rootId = aId;
  
  for c in (select ar.roleName, cr.compositeId, ft.objectId fulltextId from aq_aggregate a
            left join aq_fulltext ft on ft.aggregateId = a.objectId
            left join aq_aggregate_roles ar on ar.aggregateId = a.objectId
            left join aq_composite_roles cr on cr.roleName = ar.roleName and cr.compositeSize = 1
            where a.objectId = aId)
  loop
    if c.roleName is null then
      -- aggregate doesn't require roles
      begin
        select compositeId into nextCompositeId from aq_composite_roles where compositeSize = 0;
      exception when no_data_found then
        select aq_composite_roles_s.nextval into nextCompositeId from dual;
        insert into aq_composite_roles (compositeId, roleName, compositeSize)
          values (nextCompositeId, null, 0);
      end;
    else 
      if c.compositeId is null then
        -- we must create the composite role with size 1
        select aq_composite_roles_s.nextval into nextCompositeId from dual;
        insert into aq_composite_roles (compositeId, roleName, compositeSize)
          values (nextCompositeId, c.roleName, 1);
      else
        select c.compositeId into nextCompositeId from dual;
      end if;
    end if;
    
    -- insert the self link
    insert into aq_aggregate_links (rootId, aggregateId, compositeRoleId, fulltextId) values (aId, aId, nextCompositeId, c.fulltextId);
  end loop;
  
  -- create the remaining links
  for link in (select distinct a.parentId, a.childId, ar.roleName childRoleName, ft.objectId fulltextId, level
            from aq_agg_aggregates a
            left join aq_fulltext ft on ft.aggregateId = a.childId
            left join aq_aggregate_roles ar on ar.aggregateId = a.childId
            start with parentId = aId
            connect by nocycle parentId = prior childId
            order by level)
  loop
    for parentPath in (select compositeRoleId from aq_aggregate_links where rootId = aId and aggregateId = link.parentId)
    loop
      if link.childRoleName is null then
        -- child doesn't require any roles
        select parentPath.compositeRoleId into nextCompositeId from dual;
      else
        begin
          -- child role included in parentPath roles ?
          select compositeId into nextCompositeId from aq_composite_roles where compositeId = parentPath.compositeRoleId and roleName = link.childRoleName;
        exception when no_data_found then
          begin
            -- equivalent composite role exists ?
            select compositeSize + 1 into nextCompositeSize
            from aq_composite_roles where compositeId = parentPath.compositeRoleId
            group by compositeId, compositeSize;
            
            select compositeId into nextCompositeId
            from aq_composite_roles where compositeSize = nextCompositeSize and roleName in (
              select roleName from aq_composite_roles where compositeId = parentPath.compositeRoleId
              union select link.childRoleName from dual
            ) group by compositeId, compositeSize having count(roleName) = nextCompositeSize;
          exception when no_data_found then
            -- create new composite role
            select aq_composite_roles_s.nextval into nextCompositeId from dual;
            
            insert into aq_composite_roles (compositeId, roleName, compositeSize)
              select nextCompositeId, roleName, nextCompositeSize from aq_composite_roles where compositeId = parentPath.compositeRoleId union
              select nextCompositeId, link.childRoleName, nextCompositeSize from dual;
          when too_many_rows then raise_application_error(-20999, 'too many rows. parentPath.compositeRoleId = ' || parentPath.compositeRoleId || ', childRoleName = ' || link.childRoleName || ', nextCompositeSize = ' || nextCompositeSize);
          end;
        end;
      end if;

      select count(*) into pathExists from aq_aggregate_links where rootId = aId and aggregateId = link.childId and compositeRoleId = nextCompositeId;
      if pathExists = 0 then
        insert into aq_aggregate_links (rootId, aggregateId, compositeRoleId, fulltextId) values (aId, link.childId, nextCompositeId, link.fulltextId);
      end if;
    end loop;
  end loop;
  
  -- link documents
  for link in (select links.compositeRoleId, dl.documentId, dr.roleName, ft.objectId fulltextId
            from aq_aggregate_links links inner join aq_agg_documents dl on dl.aggregateId = links.aggregateId 
            left join aq_fulltext ft on ft.documentId = dl.documentId
            left join aq_document_roles dr on dr.documentId = dl.documentId 
            where links.rootId = aId)
  loop
    if link.roleName is null then
      -- document doesn't require roles
      select link.compositeRoleId into nextCompositeId from dual;
    else
        begin
          -- document role included in aggregate roles ?
          select compositeId into nextCompositeId from aq_composite_roles where compositeId = link.compositeRoleId and roleName = link.roleName;
        exception when no_data_found then
          begin
            -- equivalent composite role exists ?
            select compositeSize + 1 into nextCompositeSize
            from aq_composite_roles where compositeId = link.compositeRoleId
            group by compositeId, compositeSize;
            
            select compositeId into nextCompositeId
            from aq_composite_roles where compositeSize = nextCompositeSize and roleName in (
              select roleName from aq_composite_roles where compositeId = link.compositeRoleId
              union select link.roleName from dual
            ) group by compositeId, compositeSize having count(roleName) = nextCompositeSize;
          exception when no_data_found then
            -- create new composite role
            select aq_composite_roles_s.nextval into nextCompositeId from dual;
            
            insert into aq_composite_roles (compositeId, roleName, compositeSize)
              select nextCompositeId, roleName, nextCompositeSize from aq_composite_roles where compositeId = link.compositeRoleId union
              select nextCompositeId, link.roleName, nextCompositeSize from dual;
          when too_many_rows then raise_application_error(-20999, 'too many rows. c.compositeRoleId = ' || link.compositeRoleId || ', roleName = ' || link.roleName || ', nextCompositeSize = ' || nextCompositeSize);
          end;
        end;
    end if;
    
    -- insert the document link
    select count(*) into pathExists from aq_aggregate_links where rootId = aId and documentId = link.documentId and compositeRoleId = nextCompositeId;
    if pathExists = 0 then
      insert into aq_aggregate_links (rootId, documentId, compositeRoleId, fulltextId) values (aId, link.documentId, nextCompositeId, link.fulltextId);
    end if;
  end loop;
  
  -- relink ancestors
  if ancestors > 0 then
    for c in (select distinct parentId, level from aq_agg_aggregates
              start with childId = aId
              connect by nocycle childId = prior parentId
              order by level)
    loop
      denormalize_aggregate_links(c.parentId, 0);
    end loop;
  end if;
end; -- end
/

create or replace procedure denormalize_document_links (id varchar2) as
begin -- begin
  for c in (select aggregateId from aq_agg_documents where documentId = id)
  loop
  	denormalize_aggregate_links(c.aggregateId, 1);
  end loop;
end; -- end
/

insert into aggregate_Releases (id, version, releasedate, description) VALUES(aggregate_releases_s.nextval, 'fulltext 9.7.2 seq-01', SYSDATE, 'Upgrades for authorization and performance on large databases.');