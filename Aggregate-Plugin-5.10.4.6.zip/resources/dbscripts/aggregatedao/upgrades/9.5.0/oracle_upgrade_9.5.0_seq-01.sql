-- Oracle upgrade script for the AggregateDAO plugin of Blueriq release 9.5.0
--
-- Adds table in which database updates are tracked.
-- Adds the applicationId column to the aq_aggregate table
-- 
-- Needs to be executed on Blueriq databases for versions equal to or before 9.4.2

ALTER TABLE aq_aggregate ADD applicationId varchar2(200 char);

CREATE TABLE aggregate_Releases (id number(19,0) not null, description varchar2(150 char), releaseDate timestamp not null, version varchar2(100 char) not null, primary key (id));
INSERT INTO aggregate_Releases (id, version, releasedate, description) VALUES(S_dossier_releaseId.NEXTVAL, '9.5.0 seq-01', SYSDATE, 'Adds table in which database updates are tracked. Adds the applicationId column to the aq_aggregate table');
