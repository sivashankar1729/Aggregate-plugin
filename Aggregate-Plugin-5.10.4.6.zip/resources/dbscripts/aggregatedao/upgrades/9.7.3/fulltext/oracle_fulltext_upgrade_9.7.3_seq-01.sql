drop trigger if exists aq_aggregate_insert;
drop trigger if exists aq_aggregate_update;

create or replace trigger aq_aggregate_insert_update after insert or update on aq_aggregate_flat for each row
  declare cnt number(19,0);
begin
  select count(aggregateId) into cnt from aq_fulltext where aggregateId = :new.aggregateId;
  if cnt > 0 then
    update aq_fulltext set text = 'x' where aggregateId = :new.aggregateId;
  else
    insert into aq_fulltext (objectId, aggregateId, text) values (aq_fulltext_s.nextval, :new.aggregateId, 'x');
  end if;
end;

insert into aggregate_Releases (id, version, releasedate, description) VALUES(aggregate_releases_s.nextval, 'fulltext 9.7.3 seq-01', SYSDATE, 'Replaces insert and update triggers on aq_aggregate_flat with single trigger.');
