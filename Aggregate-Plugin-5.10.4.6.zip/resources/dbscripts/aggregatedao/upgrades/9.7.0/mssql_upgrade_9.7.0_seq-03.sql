create table aq_agg_aggregates (
	parentId numeric(19, 0) not null,
	childId numeric(19, 0) not null,
	
	constraint pk_aq_agg_aggregates primary key clustered (parentId, childId),
	constraint fk_aq_agg_aggregates_p foreign key (parentId) references aq_aggregate (objectId),
	constraint fk_aq_agg_aggregates_c foreign key (childId) references aq_aggregate (objectId)
);

create table aq_agg_documents (
	aggregateId numeric(19, 0) not null,
	documentId varchar(50) not null, 
	
	constraint pk_aq_agg_documents primary key (aggregateId, documentId),
	constraint fk_aq_agg_documents_a foreign key (aggregateId) references aq_aggregate (objectId) on delete cascade,
	constraint fk_aq_agg_documents_d foreign key (documentId) references aq_documents (documentId) on delete cascade
);

insert into aggregate_Releases (version, releasedate, description) values('9.7.0 seq-03', CURRENT_TIMESTAMP, 'Adds tables for storing aggregate -> aggregate and aggregate -> document links.');