declare
  v number;
begin
  -- 9.5.0 upgrade script mistakenly used S_dossier_releaseId sequence
  begin
    select last_number into v from user_sequences where sequence_name = 'S_DOSSIER_RELEASEID';
  exception when no_data_found then
    v := 1;
  end;
  
  execute immediate 'create sequence aggregate_releases_s start with ' || (v+1);
  execute immediate 'insert into aggregate_Releases (id, version, releasedate, description) VALUES(aggregate_releases_s.nextval, ''9.7.0 seq-01'', SYSDATE, ''Adds aggregate_releases_s sequence.'')';
end;
