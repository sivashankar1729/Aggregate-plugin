declare
  -- begin
  object_exists number(1,0);
  -- end
begin -- begin
	select count(*) into object_exists from user_objects where object_type = 'TABLE' and object_name = 'AQ_AGGREGATE_FLAT';
	if object_exists = 1 then
		execute immediate 'drop table aq_aggregate_flat cascade constraints';
	end if;
	
	select count(*) into object_exists from user_objects where object_type = 'TABLE' and object_name = 'AQ_AGGREGATE_ROLES';
	if object_exists = 1 then
		execute immediate 'drop table aq_aggregate_roles cascade constraints';
	end if;
	
	select count(*) into object_exists from user_objects where object_type = 'TABLE' and object_name = 'AQ_COMPOSITE_ROLES';
	if object_exists = 1 then
		execute immediate 'drop table aq_composite_roles cascade constraints';
	end if;
	
	select count(*) into object_exists from user_objects where object_type = 'SEQUENCE' and object_name = 'AQ_COMPOSITE_ROLES_S';
	if object_exists = 1 then
		execute immediate 'drop sequence aq_composite_roles_s';
	end if;	
	
	select count(*) into object_exists from user_objects where object_type = 'TABLE' and object_name = 'AQ_AGGREGATE_LINKS';
	if object_exists = 1 then
		execute immediate 'drop table aq_aggregate_links cascade constraints';
	end if;
	
	select count(*) into object_exists from user_objects where object_type = 'TABLE' and object_name = 'AQ_FULLTEXT';
	if object_exists = 1 then
		execute immediate 'drop table aq_fulltext cascade constraints';
	end if;
	
	select count(*) into object_exists from user_objects where object_type = 'SEQUENCE' and object_name = 'AQ_FULLTEXT_S';
	if object_exists = 1 then
		execute immediate 'drop sequence aq_fulltext_s';
	end if;
	
	select count(*) into object_exists from user_objects where object_type = 'PROCEDURE' and object_name = 'AQ_FULLTEXT_DS';
	if object_exists = 1 then	
		execute immediate 'drop procedure aq_fulltext_ds';
	end if;

	select count(*) into object_exists from user_objects where object_type = 'PROCEDURE' and object_name = 'DENORMALIZE_AGGREGATE_LINKS';
	if object_exists = 1 then	
		execute immediate 'drop procedure denormalize_aggregate_links';
	end if;
	
	select count(*) into object_exists from user_objects where object_type = 'PROCEDURE' and object_name = 'DENORMALIZE_DOCUMENT_LINKS';
	if object_exists = 1 then	
		execute immediate 'drop procedure denormalize_document_links';
	end if;
	
	select count(*) into object_exists from ctx_user_preferences where pre_name='AQ_FULLTEXT_UDS';
	if object_exists = 1 then
		ctx_ddl.drop_preference('aq_fulltext_uds');
	end if;
end; -- end