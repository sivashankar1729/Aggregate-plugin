-- privilege required for creating full-text index
grant execute on ctx_ddl to blueriq;

-- privilege required for sync-ing the full-text index at regular intervals (can be revoked if not used)
grant create job to blueriq;