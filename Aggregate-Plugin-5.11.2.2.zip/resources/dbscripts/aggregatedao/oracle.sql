-- if executed from Oracle SQL Developer, set Tools->Preferences->Database->PL/SQL Compiler -> PLScope Identifiers = None
-- or execute "ALTER SESSION SET PLSCOPE_SETTINGS = 'IDENTIFIERS:NONE';"

create table aq_sequence_block (
	entityName varchar2(255 char),
	nextId number(19,0) not null,
	
	constraint pk_aq_sequence_block primary key (entityName)
);

create table aq_aggregate (
	objectId number(19,0) not null,
	aggregateId number(19,0) not null,
	version number(19,0) not null,
	applicationId varchar2(200 char),
	type varchar2(100 char),
	creationDate timestamp,
	createdByUsername varchar2(100 char),
	createdById varchar2(100 char),
	lastUpdated timestamp,
	lastUpdatedByUsername varchar2(100 char),
	lastUpdatedById varchar2(100 char),
	latest number(1,0) not null,
	data clob not null,
	
	constraint pk_aq_aggregate primary key (objectId),
	constraint uk_aq_aggregate unique (aggregateId, version)
);

create sequence aggregate_s;
create index idx_aggregate_type on aq_aggregate (type);
create index idx_aggregate_latest on aq_aggregate (latest);

create table aq_documents (
	documentId varchar2(255 char) not null,
	caseId number(19,0),
	content blob not null,
	contentSize number(19, 0) not null,
	contentType varchar2(255 char) null,
	name varchar2(100 char) not null,
	creationDate timestamp not null,
	createdBy varchar2(255 char),
	lastUpdated timestamp,
	lastUpdatedBy varchar2(255 char),
	
	constraint pk_aq_documents primary key (documentId)	
);

create table aq_document_property (
	id number(19, 0) not null,
	name varchar2(100 char) not null,
	documentId varchar2(255 char) not null,
	
	constraint pk_aq_document_property primary key (id),
	constraint fk_aq_document_property_v foreign key (documentId) references aq_documents on delete cascade
);

create sequence aq_document_property_s;
create index idx_aq_document_property_d on aq_document_property (documentId);
create index idx_aq_document_property_n on aq_document_property (name);

create or replace trigger aq_document_property_insert before insert on aq_document_property for each row
begin -- begin
	:new.id := aq_document_property_s.nextval;
end; -- end
/

create table aq_document_property_value (
	id number(19,0) not null, 
	type varchar2(20 char) not null, 
	binaryValue blob, 
	booleanValue number(1,0), 
	currencyValue double precision, 
	dateTimeValue timestamp, 
	dateValue date, 
	entityValue varchar2(255 char), 
	integerValue number(19,0), 
	numberValue double precision, 
	percentageValue double precision, 
	stringValue varchar2(255 char), 
	documentPropertyId number(19,0) not null, 
	
	constraint pk_aq_doc_property_value primary key (id),
	constraint fk_aq_doc_property_value_d foreign key (documentPropertyId) references aq_document_property on delete cascade 	
);
create sequence aq_document_property_value_s;
create index idx_aq_doc_property_value_d on aq_document_property_value (documentPropertyId);

create or replace trigger aq_doc_property_value_insert before insert on aq_document_property_value for each row
begin -- begin
	:new.id := aq_document_property_value_s.nextval;
end; -- end
/

create table aq_document_roles (
	id number(19,0) not null,
	documentId varchar2(255 char) not null,
	roleName varchar2(100 char) not null,
	
	constraint pk_aq_document_roles primary key (id),
	constraint fk_aq_document_roles_d foreign key (documentId) references aq_documents (documentId) on delete cascade
);
create index idx_aq_document_roles_d on aq_document_roles(documentId);
create index idx_aq_document_roles_r on aq_document_roles(roleName);
create sequence aq_document_role_s;

create or replace trigger aq_document_roles_insert before insert on aq_document_roles for each row
begin -- begin
	:new.id := aq_document_role_s.nextval;
end; -- end
/

create table aq_agg_aggregates (
	parentId number(19, 0) not null,
	childId number(19, 0) not null,
	latest number(1,0) not null,
	
	constraint pk_aq_agg_aggregates primary key (parentId, childId, latest),
	constraint fk_aq_agg_aggregates_p foreign key (parentId) references aq_aggregate (objectId),
	constraint fk_aq_agg_aggregates_c foreign key (childId) references aq_aggregate (objectId)
);

create table aq_agg_documents (
	aggregateId number(19, 0),
	documentId varchar2(255 char),
	
	constraint pk_aq_agg_documents primary key (aggregateId, documentId),
	constraint fk_aq_agg_documents_a foreign key (aggregateId) references aq_aggregate (objectId) on delete cascade,
	constraint fk_aq_agg_documents_d foreign key (documentId) references aq_documents (documentId) on delete cascade
);


create table aggregate_metadata (
	objectId number(19,0) not null,
	aggregateId number(19,0) not null, 
	name varchar2(100 char) not null, 
	seqIndex number(19,0) not null, 
	booleanValue number(1,0), 
	currencyValue float(126), 
	dateTimeValue timestamp, 
	dateValue timestamp, 
	intValue number(19,0), 
	numberValue float(126), 
	percentageValue float(126), 
	stringValue varchar2(511 char), 
	
	constraint pk_aggregate_metadata primary key (objectId),
	constraint fk_aggregate_metadata_a foreign key (aggregateId) references aq_aggregate (objectId) on delete cascade
);
create sequence metadata_s;
create index idx_am_ans on aggregate_metadata (aggregateId, name, seqIndex);
create index idx_am_boolean on aggregate_metadata (name,booleanValue,aggregateId);
create index idx_am_currency on aggregate_metadata (name,currencyValue,aggregateId);
create index idx_am_date on aggregate_metadata (name,dateValue,aggregateId);
create index idx_am_datetime on aggregate_metadata (name,dateTimeValue,aggregateId);
create index idx_am_int on aggregate_metadata (name,intValue,aggregateId);
create index idx_am_number on aggregate_metadata (name,numberValue,aggregateId);
create index idx_am_percentage on aggregate_metadata (name,percentageValue,aggregateId);
create index idx_am_string on aggregate_metadata (name,stringValue,aggregateId);

create table aggregate_Releases (
	id number(19,0) not null, 
	description varchar2(150 char), 
	releaseDate timestamp not null, 
	version varchar2(100 char) not null, 
	primary key (id)
);
create sequence aggregate_releases_s;