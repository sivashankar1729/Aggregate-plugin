/**
 * Create sequence blocks table
 */
create table aq_sequence_block (
	[entityName] varchar(255),
	nextId numeric(19,0) not null,
	
	primary key (entityName)
);

/** 
 * Create aggregate table 
 */
create table aq_aggregate (
	[objectId] numeric(19,0) identity(1,1),
	[aggregateId] numeric(19,0) not null,
	[version] numeric(19,0) not null,
	[applicationId] varchar(200),
	[type] varchar(100), 
	[creationDate] datetime2, 
	[createdByUsername] varchar(100), 
	[createdById] varchar(100), 
	[lastUpdated] datetime2, 
	[lastUpdatedByUsername] varchar(100), 
	[lastUpdatedById] varchar(100),
	[latest] bit not null,
	[data] text not null,

	primary key clustered ([objectId] asc),
	constraint uk_aggregate_aggregateId_version unique nonclustered ([aggregateId] asc, [version] asc)
);

create nonclustered index idx_aggregate_latest on aq_aggregate (latest);
create nonclustered index idx_aggregate_type on aq_aggregate ([type]);

create table aq_documents (
	documentId varchar(255) not null, 
	caseId numeric(19,0) null, 
	content image not null, 
	contentSize numeric(19,0) not null,
	contentType varchar(255) null, 
	name varchar(100) not null, 
	creationDate datetime2 not null, 
	createdBy varchar(255) null,
	lastUpdated datetime2 null,
	lastUpdatedBy varchar(255) null,
	
	constraint pk_aq_documents primary key (documentId)
);

create table aq_document_property (
	id numeric(19,0) identity not null, 
	name varchar(100) not null, 
	documentId varchar(255) not null,
	
	constraint pk_aq_document_property primary key (id),
	constraint fk_aq_document_property_d foreign key (documentId) references aq_documents on delete cascade
);

create index idx_aq_document_property_d on aq_document_property (documentId);
create index idx_aq_document_property_n on aq_document_property (name);

create table aq_document_property_value (
	id numeric(19,0) identity not null, 
	type varchar(20) not null, 
	binaryValue image null, 
	booleanValue tinyint null, 
	currencyValue double precision null, 
	dateTimeValue datetime null, 
	dateValue datetime null, 
	entityValue varchar(255) null, 
	integerValue numeric(19,0) null, 
	numberValue double precision null, 
	percentageValue double precision null, 
	stringValue varchar(255) null, 
	documentPropertyId numeric(19,0) not null,
	
	constraint pk_aq_doc_property_value primary key (id),
	constraint fk_aq_doc_property_value_d foreign key (documentPropertyId) references aq_document_property on delete cascade
);
create index idx_aq_doc_property_value_d on aq_document_property_value (documentPropertyId);

create table aq_document_roles (
	id numeric(19,0) identity not null,
	documentId varchar(255) not null,
	roleName varchar(100) not null,
	
	constraint pk_aq_document_roles primary key (id),
	constraint fk_aq_document_roles_d foreign key (documentId) references aq_documents (documentId) on delete cascade
);
create index idx_aq_document_roles_d on aq_document_roles(documentId);
create index idx_aq_document_roles_r on aq_document_roles(roleName);


create table aq_agg_aggregates (
	parentId numeric(19, 0) not null,
	childId numeric(19, 0) not null,
	latest bit not null,
	
	constraint pk_aq_agg_aggregates primary key clustered (parentId, childId, latest),
	constraint fk_aq_agg_aggregates_p foreign key (parentId) references aq_aggregate (objectId),
	constraint fk_aq_agg_aggregates_c foreign key (childId) references aq_aggregate (objectId)
);

create table aq_agg_documents (
	aggregateId numeric(19, 0) not null,
	documentId varchar(255) not null, 
	
	constraint pk_aq_agg_documents primary key (aggregateId, documentId),
	constraint fk_aq_agg_documents_a foreign key (aggregateId) references aq_aggregate (objectId) on delete cascade,
	constraint fk_aq_agg_documents_d foreign key (documentId) references aq_documents (documentId) on delete cascade
);

/**
 * Create metadata table 
 */
create table aggregate_metadata (
	[objectId] numeric(19, 0) identity(1,1),
	[aggregateId] numeric(19,0) not null, 
	[name] varchar(255) not null, 
	[seqIndex] numeric(19,0) not null, 
	[booleanValue] tinyint null, 
	[currencyValue] float null, 
	[dateValue] datetime null, 
	[dateTimeValue] datetime null, 
	[intValue] numeric(19,0) null, 
	[numberValue] float null, 
	[percentageValue] float null, 
	[stringValue] varchar(511) null, 

	primary key clustered (objectId),
	foreign key ([aggregateId]) references aq_aggregate ([objectId]) on delete cascade
);

create nonclustered index idx_am_ans on aggregate_metadata ([aggregateId] asc, [name] asc, [seqIndex] asc);
create nonclustered index idx_am_boolean on aggregate_metadata (name, booleanValue, aggregateId)
create nonclustered index idx_am_currency on aggregate_metadata (name, currencyValue, aggregateId)
create nonclustered index idx_am_date on aggregate_metadata (name, dateValue, aggregateId)
create nonclustered index idx_am_datetime on aggregate_metadata (name, dateTimeValue, aggregateId)
create nonclustered index idx_am_int on aggregate_metadata (name, intValue, aggregateId)
create nonclustered index idx_am_number on aggregate_metadata (name, numberValue, aggregateId)
create nonclustered index idx_am_percentage on aggregate_metadata (name, percentageValue, aggregateId)
create nonclustered index idx_am_string on aggregate_metadata (name, stringValue, aggregateId)


create table aggregate_Releases (
	id numeric(19,0) identity not null, 
	description varchar(150) null, 
	releaseDate datetime not null, 
	version varchar(100) not null, 
	primary key (id)
);
