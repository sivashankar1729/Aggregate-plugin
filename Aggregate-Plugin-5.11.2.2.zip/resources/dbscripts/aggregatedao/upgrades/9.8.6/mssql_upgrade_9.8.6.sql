drop index idx_am_int on aggregate_metadata;

alter table aggregate_metadata alter column intValue numeric(19,0) null;

create nonclustered index idx_am_int on aggregate_metadata (name, intValue, aggregateId)