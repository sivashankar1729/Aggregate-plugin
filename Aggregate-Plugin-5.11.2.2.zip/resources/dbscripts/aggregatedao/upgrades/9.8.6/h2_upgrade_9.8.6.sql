drop index idx_am_int on aggregate_metadata;

alter table aggregate_metadata alter column intValue bigint null;

create nonclustered index idx_am_int on aggregate_metadata (name, intValue, aggregateId)