-- MSSQL upgrade script for the AggregateDAO plugin of Blueriq release 9.5.0
--
-- Adds table in which database updates are tracked.
-- Adds the applicationId column to the aq_aggregate table
-- 
-- Needs to be executed on Blueriq databases for versions equal to or before 9.4.2

ALTER TABLE aq_aggregate ADD applicationId varchar(200);

CREATE TABLE aggregate_Releases (id numeric(19,0) identity not null, description varchar(150) null, releaseDate datetime not null, version varchar(100) not null, primary key (id));
INSERT INTO aggregate_Releases (version, releasedate, description) VALUES('9.5.0 seq-01', CURRENT_TIMESTAMP, 'Adds table in which database updates are tracked. Adds the applicationId column to the aq_aggregate table');
