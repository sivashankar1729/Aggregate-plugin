alter table aggregate_metadata alter column currencyValue double null;
alter table aggregate_metadata alter column numberValue double null;
alter table aggregate_metadata alter column percentageValue double null;
