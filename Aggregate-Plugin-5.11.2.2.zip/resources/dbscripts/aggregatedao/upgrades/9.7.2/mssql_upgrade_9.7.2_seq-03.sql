alter table aq_agg_aggregates drop constraint pk_aq_agg_aggregates;
alter table aq_agg_aggregates add latest bit not null default 1;
alter table aq_agg_aggregates add constraint pk_aq_agg_aggregates primary key clustered (parentId, childId, latest);

insert into aggregate_Releases (version, releasedate, description) values('9.7.2 seq-03', CURRENT_TIMESTAMP, 'Adds column [latest] to aq_agg_aggregates table.');