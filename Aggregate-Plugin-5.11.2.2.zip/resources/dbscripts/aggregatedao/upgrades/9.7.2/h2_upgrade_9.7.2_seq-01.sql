alter table aq_documents alter column documentId varchar(255) not null;
alter table aq_document_property alter column documentId varchar(255) not null;
alter table aq_document_property_value alter column documentPropertyId bigint not null;
alter table aq_agg_documents alter column documentId varchar(255) not null;

insert into aggregate_Releases (version, releasedate, description) VALUES('9.7.2 seq-01',  CURRENT_TIMESTAMP(), 'Increases size of documentId columns to work with CMIS plugin.');
