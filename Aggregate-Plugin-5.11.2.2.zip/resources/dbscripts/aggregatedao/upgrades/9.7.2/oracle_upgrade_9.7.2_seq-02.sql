create table aq_document_roles (
	id number(19,0) not null,
	documentId varchar2(255 char) not null,
	roleName varchar2(100 char) not null,
	
	constraint pk_aq_document_roles primary key (id),
	constraint fk_aq_document_roles_d foreign key (documentId) references aq_documents (documentId) on delete cascade
);
create index idx_aq_document_roles_d on aq_document_roles(documentId);
create index idx_aq_document_roles_r on aq_document_roles(roleName);
create sequence aq_document_role_s;

create or replace trigger aq_document_roles_insert before insert on aq_document_roles for each row
begin -- begin
	:new.id := aq_document_role_s.nextval;
end; -- end
/

insert into aggregate_Releases (id, version, releasedate, description) VALUES(aggregate_releases_s.nextval, '9.7.2 seq-02', SYSDATE, 'Adds table aq_document_roles for document authorization.');