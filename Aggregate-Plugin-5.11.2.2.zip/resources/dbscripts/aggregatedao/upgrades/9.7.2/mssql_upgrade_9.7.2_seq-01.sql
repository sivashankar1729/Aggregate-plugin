drop index idx_aq_document_property_d on aq_document_property;
drop index idx_aq_doc_property_value_d on aq_document_property_value;
alter table aq_agg_documents drop constraint fk_aq_agg_documents_d;
alter table aq_document_property drop constraint fk_aq_document_property_d;

alter table aq_documents alter column documentId varchar(255) not null;
alter table aq_document_property alter column documentId varchar(255) not null;
alter table aq_document_property_value alter column documentPropertyId numeric(19,0) not null;
alter table aq_agg_documents alter column documentId varchar(255) not null;

alter table aq_agg_documents add constraint fk_aq_agg_documents_d foreign key (documentId) references aq_documents (documentId) on delete cascade;
alter table aq_document_property add constraint fk_aq_document_property_d foreign key (documentId) references aq_documents(documentId) on delete cascade;
create index idx_aq_document_property_d on aq_document_property (documentId);
create index idx_aq_doc_property_value_d on aq_document_property_value (documentPropertyId);

insert into aggregate_Releases (version, releasedate, description) values('9.7.2 seq-01', CURRENT_TIMESTAMP, 'Increases size of documentId columns to work with CMIS plugin.');