create table aq_document_roles (
	id numeric(19,0) identity not null,
	documentId varchar(255) not null,
	roleName varchar(100) not null,
	
	constraint pk_aq_document_roles primary key (id),
	constraint fk_aq_document_roles_d foreign key (documentId) references aq_documents (documentId) on delete cascade
);
create index idx_aq_document_roles_d on aq_document_roles(documentId);
create index idx_aq_document_roles_r on aq_document_roles(roleName);

insert into aggregate_Releases (version, releasedate, description) values('9.7.2 seq-02', CURRENT_TIMESTAMP, 'Adds table aq_document_roles for document authorization.');