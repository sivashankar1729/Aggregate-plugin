drop index idx_am_boolean on aggregate_metadata
drop index idx_am_currency on aggregate_metadata
drop index idx_am_date on aggregate_metadata
drop index idx_am_datetime on aggregate_metadata
drop index idx_am_int on aggregate_metadata
drop index idx_am_number on aggregate_metadata
drop index idx_am_percentage on aggregate_metadata
drop index idx_am_string on aggregate_metadata

create nonclustered index idx_am_boolean on aggregate_metadata (name, booleanValue, aggregateId)
create nonclustered index idx_am_currency on aggregate_metadata (name, currencyValue, aggregateId)
create nonclustered index idx_am_date on aggregate_metadata (name, dateValue, aggregateId)
create nonclustered index idx_am_datetime on aggregate_metadata (name, dateTimeValue, aggregateId)
create nonclustered index idx_am_int on aggregate_metadata (name, intValue, aggregateId)
create nonclustered index idx_am_number on aggregate_metadata (name, numberValue, aggregateId)
create nonclustered index idx_am_percentage on aggregate_metadata (name, percentageValue, aggregateId)
create nonclustered index idx_am_string on aggregate_metadata (name, stringValue, aggregateId)

insert into aggregate_Releases (version, releasedate, description) values('9.7.2 seq-03', CURRENT_TIMESTAMP, 'Upgrades aggregate metadata indexes.');