drop index idx_am_boolean;
drop index idx_am_currency;
drop index idx_am_date;
drop index idx_am_datetime;
drop index idx_am_int;
drop index idx_am_number;
drop index idx_am_percentage;
drop index idx_am_string;

create index idx_am_boolean on aggregate_metadata (name,booleanValue,aggregateId);
create index idx_am_currency on aggregate_metadata (name,currencyValue,aggregateId);
create index idx_am_date on aggregate_metadata (name,dateValue,aggregateId);
create index idx_am_datetime on aggregate_metadata (name,dateTimeValue,aggregateId);
create index idx_am_int on aggregate_metadata (name,intValue,aggregateId);
create index idx_am_number on aggregate_metadata (name,numberValue,aggregateId);
create index idx_am_percentage on aggregate_metadata (name,percentageValue,aggregateId);
create index idx_am_string on aggregate_metadata (name,stringValue,aggregateId);

insert into aggregate_Releases (id, version, releasedate, description) VALUES(aggregate_releases_s.nextval, '9.7.2 seq-03', SYSDATE, 'Upgrades aggregate metadata indexes.');