create index idx_aggregate_type on aq_aggregate (type);

insert into aggregate_Releases (id, version, releasedate, description) VALUES(aggregate_releases_s.nextval, '9.7.0 seq-02', SYSDATE, 'Adds index on aq_aggregate(type).');