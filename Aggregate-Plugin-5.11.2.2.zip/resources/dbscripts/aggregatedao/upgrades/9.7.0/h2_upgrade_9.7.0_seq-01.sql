create index idx_aggregate_type on aq_aggregate (type);

insert into aggregate_Releases (version, releasedate, description) VALUES('9.7.0 seq-01',  CURRENT_TIMESTAMP(), 'Adds index on aq_aggregate(type).');