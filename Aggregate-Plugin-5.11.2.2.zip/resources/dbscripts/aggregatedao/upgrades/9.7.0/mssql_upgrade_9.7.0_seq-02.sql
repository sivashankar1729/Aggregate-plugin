create table aq_documents (
	documentId varchar(50) not null, 
	caseId numeric(19,0) null, 
	content image not null, 
	contentType varchar(255) not null, 
	name varchar(100) not null, 
	uploadDate datetime not null, 
	userId varchar(255) null,
	
	constraint pk_aq_documents primary key (documentId)
);

create table aq_document_property (
	id numeric(19,0) identity not null, 
	name varchar(100) not null, 
	documentId varchar(50) null,
	
	constraint pk_aq_document_property primary key (id),
	constraint fk_aq_document_property_d foreign key (documentId) references aq_documents on delete cascade
);

create index idx_aq_document_property_d on aq_document_property (documentId);
create index idx_aq_document_property_n on aq_document_property (name);

create table aq_document_property_value (
	valueType varchar(31) not null, 
	id numeric(19,0) identity not null, 
	type varchar(255) null, 
	binaryValue image null, 
	booleanValue tinyint null, 
	currencyValue double precision null, 
	dateTimeValue datetime null, 
	dateValue datetime null, 
	entityValue varchar(255) null, 
	integerValue numeric(19,0) null, 
	numberValue double precision null, 
	percentageValue double precision null, 
	stringValue varchar(255) null, 
	documentPropertyId numeric(19,0) null,
	
	constraint pk_aq_doc_property_value primary key (id),
	constraint fk_aq_doc_property_value_d foreign key (documentPropertyId) references aq_document_property on delete cascade
);
create index idx_aq_doc_property_value_d on aq_document_property_value (documentPropertyId);

insert into aggregate_Releases (version, releasedate, description) values('9.7.0 seq-02', CURRENT_TIMESTAMP, 'Adds tables for storing documents in a database.');