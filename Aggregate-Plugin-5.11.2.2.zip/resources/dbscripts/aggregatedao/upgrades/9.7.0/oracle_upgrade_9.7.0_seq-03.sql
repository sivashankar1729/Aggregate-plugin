create table aq_documents (
	documentId varchar2(50 char) not null,
	caseId number(19,0),
	content blob not null,
	contentType varchar2(255 char) not null,
	name varchar2(100 char) not null,
	uploadDate timestamp not null,
	userId varchar2(255 char),
	
	constraint pk_aq_documents primary key (documentId)	
);

create table aq_document_property (
	id number(19, 0) not null,
	name varchar2(100 char) not null,
	documentId varchar2(50 char),
	
	constraint pk_aq_document_property primary key (id),
	constraint fk_aq_document_property_v foreign key (documentId) references aq_documents on delete cascade
);
create sequence aq_document_property_s;
create index idx_aq_document_property_d on aq_document_property (documentId);
create index idx_aq_document_property_n on aq_document_property (name);

create table aq_document_property_value (
	valueType varchar2(31 char) not null, 
	id number(19,0) not null, 
	type varchar2(255 char), 
	binaryValue blob, 
	booleanValue number(1,0), 
	currencyValue double precision, 
	dateTimeValue timestamp, 
	dateValue timestamp, 
	entityValue varchar2(255 char), 
	integerValue number(19,0), 
	numberValue double precision, 
	percentageValue double precision, 
	stringValue varchar2(255 char), 
	documentPropertyId number(19,0), 
	
	constraint pk_aq_doc_property_value primary key (id),
	constraint fk_aq_doc_property_value_d foreign key (documentPropertyId) references aq_document_property on delete cascade 	
);
create sequence aq_document_property_value_s;
create index idx_aq_doc_property_value_d on aq_document_property_value (documentPropertyId);

insert into aggregate_Releases (id, version, releasedate, description) VALUES(aggregate_releases_s.nextval, '9.7.0 seq-03', SYSDATE, 'Adds tables for storing documents in a database.');